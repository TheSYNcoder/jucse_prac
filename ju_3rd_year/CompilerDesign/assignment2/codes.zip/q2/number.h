#ifndef DEFN
#define DEFN
struct number{
    
        int ival;
        double fval;
        char type;
};


struct plus{
    int p;
};

#endif
